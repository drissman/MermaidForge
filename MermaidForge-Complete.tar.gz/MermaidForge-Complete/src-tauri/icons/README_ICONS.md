# 🎨 Génération des Icônes

## Icônes manquantes à créer

Les icônes suivantes sont requises mais temporairement absentes :

```
src-tauri/icons/
├── 32x32.png
├── 128x128.png
├── 128x128@2x.png
├── icon.icns (macOS)
└── icon.ico (Windows)
```

## Solution Rapide (1 minute)

### Option A : Utiliser un générateur en ligne

1. **Aller sur** : https://icon.kitchen/
2. **Upload une image** : Logo MermaidForge ou texte "MF"
3. **Télécharger** : Package d'icônes complet
4. **Copier** dans `src-tauri/icons/`

### Option B : Utiliser tauri-icon (CLI)

```bash
# Installer
cargo install tauri-icon

# Créer à partir d'une image source (1024x1024 recommandé)
tauri-icon path/to/logo.png

# Les icônes seront générées automatiquement
```

### Option C : Icônes temporaires pour tester

Pour tester immédiatement sans vraies icônes :

```bash
cd src-tauri/icons

# Créer des placeholders (Linux/WSL2)
convert -size 32x32 xc:orange 32x32.png
convert -size 128x128 xc:orange 128x128.png
convert -size 256x256 xc:orange 128x128@2x.png
convert -size 256x256 xc:orange icon.ico

# OU télécharger des icônes génériques
wget https://raw.githubusercontent.com/tauri-apps/tauri/dev/tooling/cli/templates/app/app-icon.png
tauri-icon app-icon.png
```

## ⚠️ Important

Sans ces icônes, le build **ne fonctionnera PAS**.

**Priorité 1** : Générer les icônes AVANT de faire `npm run tauri:build`

---

**Une fois les icônes créées, supprimez ce fichier !**
